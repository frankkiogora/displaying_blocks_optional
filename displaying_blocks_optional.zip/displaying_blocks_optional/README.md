This is a coding dojo optional assignment aimed at practicing how to position items on a webpage. 
